<?php echo text_output($header, 'h1', 'page-head');?>

<p class="orange bold">Thanks to FamFamFam's Silk icon set for providing the new images for the View News pages!</p><br />

<div id="loader" class="loader">
	<?php echo img($loader);?>
	<?php echo text_output($label['loading'], 'h3', 'gray');?>
</div>

<div id="news" class="hidden">
	<?php if (isset($categories)): ?>
		<strong class="fontNormal"><?php echo $label['categories'];?></strong><br />
		<span class="fontSmall">
			<a href="#" class="all" myTitle="<?php echo $header;?>"><?php echo $label['all_news'];?></a>
			
			<?php foreach ($categories as $cat): ?>
				&middot; <a href="#" class="show" myID="<?php echo $cat['id'];?>" myTitle="<?php echo $header .' '. NDASH .' '. $cat['name'];?>"><?php echo $cat['name'];?></a>
			<?php endforeach; ?>
		</span>
	<?php endif; ?>
	
	<?php if (isset($msg)): ?>
		<?php echo $msg;?>
	<?php endif;?>
	
	<?php if (isset($news)): ?>
		<?php foreach ($news as $value): ?>
			<div class="news <?php echo $value['cat_id'];?>">
				<br />
				<?php echo text_output(anchor('main/viewnews/'. $value['id'], $value['title']), 'h3');?>
				<?php echo text_output(word_limiter($value['content'], 50));?>
				
				<p class="fontSmall gray">
					<strong><?php echo $label['author'] .'</strong> '. $value['author'];?><br />
					<strong><?php echo $label['posted_on'] .'</strong> '. $value['date'];?><br />
					<strong><?php echo $label['category'] .'</strong> '. $value['category'];?>
					
					<?php if ($value['comment_count'] > 0): ?>
						<br /><em><?php echo $value['comment_count'] .' '. $label['comments'];?></em>
					<?php endif; ?>
				</p>
			</div>
		<?php endforeach; ?>
	<?php endif; ?>
</div>